<div class="qode-blog-like">
	<?php if( function_exists('qode_get_like') ) qode_get_like(); ?>
</div>