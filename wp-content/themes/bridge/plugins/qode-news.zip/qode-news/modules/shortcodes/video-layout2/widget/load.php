<?php

include_once QODE_NEWS_SHORTCODES_PATH.'/video-layout2/widget/functions.php';
include_once QODE_NEWS_SHORTCODES_PATH.'/video-layout2/widget/video-layout2.php';