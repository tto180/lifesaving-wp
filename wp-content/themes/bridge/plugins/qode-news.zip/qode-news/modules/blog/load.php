<?php 
include_once QODE_NEWS_BLOG_PATH.'/functions.php';

//load news blog options
include_once QODE_NEWS_BLOG_PATH.'/admin/options-map/news-blog-single-map.php';

//load per page news blog options
include_once QODE_NEWS_BLOG_PATH.'/admin/meta-boxes/news-post-meta.php';