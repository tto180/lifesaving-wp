<?php

include_once QODE_MEMBERSHIP_SHORTCODES_PATH.'/register/functions.php';
include_once QODE_MEMBERSHIP_SHORTCODES_PATH.'/register/register.php';