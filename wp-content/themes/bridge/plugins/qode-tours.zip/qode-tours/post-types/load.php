<?php

require_once 'tours/lib/tours-query.php';
require_once 'tours/lib/tour-search.php';
require_once 'tours/lib/tour-pagination.php';
require_once 'tours/lib/booking-handler.php';
require_once 'tours/lib/tour-price-helper.php';
require_once 'tours/lib/helpers.php';
require_once 'tours/lib/template-helpers.php';
require_once 'tours/lib/page-templater.php';
require_once 'tours/reviews/reviews-functions.php';