<?php

define('QODE_RE_VERSION', '1.1.6');
define('QODE_RE_ABS_PATH', dirname(__FILE__));
define('QODE_RE_REL_PATH', dirname(plugin_basename(__FILE__ )));
define('QODE_RE_URL_PATH', plugin_dir_url( __FILE__ ));
define('QODE_RE_ASSETS_PATH', QODE_RE_ABS_PATH.'/assets');
define('QODE_RE_ASSETS_URL_PATH', QODE_RE_URL_PATH.'assets');
define('QODE_RE_MODULE_PATH', QODE_RE_ABS_PATH.'/modules');
define('QODE_RE_MODULE_URL_PATH', QODE_RE_URL_PATH.'modules');
define('QODE_RE_CPT_PATH', QODE_RE_ABS_PATH.'/post-types');
define('QODE_RE_CPT_URL_PATH', QODE_RE_URL_PATH.'post-types');
define('QODE_RE_SHORTCODES_PATH', QODE_RE_ABS_PATH.'/shortcodes');
define('QODE_RE_SHORTCODES_URL_PATH', QODE_RE_URL_PATH.'shortcodes');
