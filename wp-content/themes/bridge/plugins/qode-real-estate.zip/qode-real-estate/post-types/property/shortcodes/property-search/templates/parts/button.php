<div class="qodef-search-bottom-part qodef-search-button-section">
    <?php echo bridge_core_get_button_html($button_parameters); ?>
</div>
