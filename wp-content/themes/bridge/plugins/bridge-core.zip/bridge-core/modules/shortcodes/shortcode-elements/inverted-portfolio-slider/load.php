<?php

include_once BRIDGE_CORE_SHORTCODES_PATH.'/inverted-portfolio-slider/inverted-portfolio-slider.php';
include_once BRIDGE_CORE_SHORTCODES_PATH.'/inverted-portfolio-slider/helper-functions.php';