<a itemprop="url" class="portfolio_jg_image_link image_holder <?php echo esc_attr( $hover_type ); ?>" href="<?php echo esc_url( $portfolio_link ); ?>" target="<?php echo esc_attr( $target ); ?>">
    <?php echo get_the_post_thumbnail(get_the_ID(), 'full'); ?>
</a>